/**
 * Resets the user's password /
 */
module.exports = function(objectrepository) {
  return function(req, res, next) {
    return next();
  };
};
