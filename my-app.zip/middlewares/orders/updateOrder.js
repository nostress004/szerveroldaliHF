/**
 * Update order
 */

module.exports = function(objectrepository) {
  return function(req, res, next) {
    return next();
  };
};
