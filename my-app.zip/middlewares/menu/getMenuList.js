/**
 * Delete the menu list
 */

module.exports = function(objectrepository) {
  return function(req, res, next) {
    return next();
  };
};
