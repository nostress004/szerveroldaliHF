module.exports = function(app) {
  /**
   * Add new order
   */

  app.use('/order/new');

  /**
   * Edit the order details
   */

  app.use('/order/:orderid/edit');

  /**
   * Delete order
   * - then redirect to /order
   */

  app.use('/order/:orderid/delete');

  /**
   * List all orders (admin)
   */

  app.use('/orders');

  /**
   * List all orders (user)
   */

  app.use('/myorders');
};
