var express = require('express');
var path = require('path');
var app = express();

// Define the port to run on
app.set('port', 3000);
app.use(express.static(path.join(__dirname, 'public')));

// Routes
// GET    '/home' home page
// GET    '/login' whenever a user wants to login
// GET    '/register' whenever a new user wants to register
// GET    '/forgotten' in case of forgotten password
// GET    '/profile' our profile
// GET    '/menu' list of menus
// GET    '/menu/:menuid/view' get an item of the menu
// POST   '/menu/:menuid/new' add new menu item
// PUT    '/menu/:menuid/edit' update menu item
// DELETE '/menu/:menuid/delete' delete menu item
// POST   '/menu/:menuid/order' order selected item
// GET    '/orders' view orders (admin mode)
// GET    '/order/:orderid/view' view order
// POST   '/order/:orderid/new' create order
// PUT    '/order/:orderid/edit' update order status
// DELETE '/order/:orderid/delete' delete order
// GET    '/myorders' check my orders

// Middlewares
// getMenuItem
// deleteMenuItem
// updateMenuItem
// getMenuList
// getOrder
// deleteOrder
// updateOrder
// getOrderList
// auth
// checkUserLogin
// inverseAuth
// forgottenPassword
// register
// logout
// mainRedirect
// render

// Listen for requests
var server = app.listen(app.get('port'), () => {
  var port = server.address().port;
  console.log('Listening on:' + port);
});
